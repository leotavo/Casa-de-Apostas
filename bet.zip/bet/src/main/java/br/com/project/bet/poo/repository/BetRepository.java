package br.com.project.bet.poo.repository;

public class BetRepository {

}
