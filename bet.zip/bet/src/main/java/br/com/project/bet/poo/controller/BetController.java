package br.com.project.bet.poo.controller;

public class BetController {

}
