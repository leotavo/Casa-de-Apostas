package br.com.project.bet.poo.service;

public class BetService {

}
